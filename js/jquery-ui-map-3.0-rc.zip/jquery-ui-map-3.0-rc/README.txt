jquery-ui-map version 3.0-rc1

Breaking changes:
1. find does no longer accept the delimiter property
2. find has a new property operator
3. addMarker does no longer accept a 3 parameter
4. iw is no longer set by default, rather use closeInfoWindow

Documentation: http://code.google.com/p/jquery-ui-map/wiki/Overview

Demo: http://code.google.com/p/jquery-ui-map/

Issues: http://code.google.com/p/jquery-ui-map/issues/list

Discuss at: http://groups.google.com/group/jquery-ui-map-discuss



